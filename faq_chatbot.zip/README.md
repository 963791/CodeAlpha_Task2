# FAQ Chatbot 🤖

A Streamlit-based chatbot for answering FAQs using NLP and cosine similarity.

## Run Locally

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Live Demo

Deploy on [Streamlit Cloud](https://share.streamlit.io/)
